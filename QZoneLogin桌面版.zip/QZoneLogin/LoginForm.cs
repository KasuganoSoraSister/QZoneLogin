﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using SufeiUtil;
using DotNet.Utilities;

namespace QZoneLogin
{
    public partial class LoginForm : Form
    {
        public int hasimage = 0;   //表示是否含有验证码图片
        private string QQ = null;
        private string password = null;
        private string verifycode = null;
        private HttpResult outcomeFromLogin = new HttpResult();
        private HttpResult outcomeFromCheck = new HttpResult();
        private Int32 qq_num = 0;
        private string ptv = "";
        private string pt_login_sig;
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HttpHelper helper1 = new HttpHelper();
            
            if (QQ_acount_box.Text == null)
            {
                MessageBox.Show("账号不能为空");
            }
            if (QQ_pass_box.Text == null)
            {
                MessageBox.Show("密码不能为空");
            }
            if (Vericode_box.Text == null)
            {
                MessageBox.Show("验证码不能为空");
            }
            //string pass = helper2.GetPassword(this.QQ, this.password, Vericode_box.Text);
            String forLoginUrl = "https://ssl.ptlogin2.qq.com/login?u=" + QQ + "&verifycode=" + Vericode_box.Text + "&pt_vcode_v1=0&pt_verifysession_v1="+ ptv + "&p=" + 
                GetEncryption() + "&pt_randsalt=2&pt_jstoken=3611214356&u1=" +
                "https://qzs.qzone.qq.com/qzone/v5/loginsucc.html?para=izone&from=iqq" +
                "&ptredirect=0&h=1&t=1&g=1&from_ui=1&ptlang=2052&action=25-109-1511246767895&js_ver=10232&js_type=1&login_sig=" +
                 pt_login_sig + "&pt_uistyle=40&aid=549000912&daid=5&has_onekey=1&";

            HttpItem h = new HttpItem
            {
                URL = forLoginUrl,
                ResultCookieType = ResultCookieType.CookieCollection,
            };
            outcomeFromLogin = helper1.GetHtml(h);
            String revFromLogin = outcomeFromLogin.Html;
            Return_box.Text = revFromLogin; //打印登录后返回信息
            int a = revFromLogin.IndexOf("ptsigx=");
            int i = a + 7;
            string ptsigx = "";
            while (revFromLogin[i] != '&')
                ptsigx += revFromLogin[i++];


            //https://ptlogin2.qzone.qq.com/check_sig?pttype=1&uin=66456804&service=login&nodirect=0&ptsigx=9051e9b66a006e60ed2a838af1996fc46ee40999399830ca617d84da9329386ed5411a5e3db97d0303552214c8be9de48aa821779428b16cbd076339b187a564&s_url=https%3A%2F%2Fqzs.qzone.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&f_url=&ptlang=2052&ptredirect=100&aid=549000912&daid=5&j_later=0&low_login_hour=0&regmaster=0&pt_login_type=1&pt_aid=0&pt_aaid=0&pt_light=0&pt_3rd_aid=0'

            String forCheckUrl = "https://ptlogin2.qzone.qq.com/check_sig?pttype=1&uin=" +
                QQ +
                "&service=login&nodirect=0&ptsigx=" +
                ptsigx +
                "&s_url=https%3A%2F%2Fqzs.qzone.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone%26from%3Diqq&f_url=&ptlang=2052&ptredirect=100&aid=549000912&daid=5&j_later=0&low_login_hour=0&regmaster=0&pt_login_type=1&pt_aid=0&pt_aaid=0&pt_light=0&pt_3rd_aid=0";
            HttpItem Check = new HttpItem
            {
                URL = forCheckUrl,
                ResultCookieType = ResultCookieType.CookieCollection,
            };
            HttpResult HR = helper1.GetHtml(Check);
            //至此登录成功


            string MyCookie = "";
            MyCookie += HttpCookieHelper.CookieFormat("uin", HttpCookieHelper.GetCookieValue("uin", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("skey", HttpCookieHelper.GetCookieValue("skey", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("p_skey", HttpCookieHelper.GetCookieValue("p_skey", HR.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("p_uin", HttpCookieHelper.GetCookieValue("uin", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("RK", HttpCookieHelper.GetCookieValue("RK", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("o_cookie", QQ);
            MyCookie += HttpCookieHelper.CookieFormat("pac_uid", "1_" + QQ);
            MyCookie += HttpCookieHelper.CookieFormat("p_o2_uin",  QQ);
            MyCookie += HttpCookieHelper.CookieFormat("pt2gguin", HttpCookieHelper.GetCookieValue("pt2gguin", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("__guid", "152210621.1751587825425463300.1506496536652.0693");
            MyCookie += HttpCookieHelper.CookieFormat("__layoutStat", "22");
            MyCookie += HttpCookieHelper.CookieFormat("__Q_w_s__QZN_TodoMsgCnt", "1");
            MyCookie += HttpCookieHelper.CookieFormat("__Q_w_s_hat_seed", "1");
            MyCookie += HttpCookieHelper.CookieFormat("_qpsvr_localtk", "0.925299199850028");
            MyCookie += HttpCookieHelper.CookieFormat("_qz_referrer", "i.qq.com");
            MyCookie += HttpCookieHelper.CookieFormat("cpu_performance_v8", "4");
            MyCookie += HttpCookieHelper.CookieFormat("device", "");
            MyCookie += HttpCookieHelper.CookieFormat("eas_sid", "i1d530x6y4B9I461U7j0V1B5S0");
            MyCookie += HttpCookieHelper.CookieFormat("LW_pid", "b368531a794f769d66958231b26c8667");
            MyCookie += HttpCookieHelper.CookieFormat("Loading", "Yes");
            MyCookie += HttpCookieHelper.CookieFormat("LW_PsKey", "bd9353e0570ca0d80450978c03b4a860");
            MyCookie += HttpCookieHelper.CookieFormat("LW_sid", "k135M0d9C1J9P1N8v0q7V5C1e3");
            MyCookie += HttpCookieHelper.CookieFormat("LW_TS", "1508678555");
            MyCookie += HttpCookieHelper.CookieFormat("LW_uid", "p1Q5F0i8s0T4V7l6v3y9L2n508");
            MyCookie += HttpCookieHelper.CookieFormat("ptcz", HttpCookieHelper.GetCookieValue("ptcz", outcomeFromLogin.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("pt4_token", HttpCookieHelper.GetCookieValue("pt4_token", HR.Cookie));
            MyCookie += HttpCookieHelper.CookieFormat("pgv_flv", "27.0");
            MyCookie += HttpCookieHelper.CookieFormat("pgv_info", "ssid=s8104241564");
            MyCookie += HttpCookieHelper.CookieFormat("pgv_pvi", "480260096");
            MyCookie += HttpCookieHelper.CookieFormat("pgv_pvid", "1016919912");
            MyCookie += HttpCookieHelper.CookieFormat("pgv_pvid_new", QQ + "_9ee5509b4b");
            MyCookie += HttpCookieHelper.CookieFormat("pgv_si", "s2057056256");
            MyCookie += HttpCookieHelper.CookieFormat("ptisp", "cnc");
            MyCookie += HttpCookieHelper.CookieFormat("ptui_loginuin", QQ);
            MyCookie += HttpCookieHelper.CookieFormat("QZ_FE_WEBP_SUPPORT", "0");
            MyCookie += HttpCookieHelper.CookieFormat("qz_screen", "1920x1080");
            MyCookie += HttpCookieHelper.CookieFormat("r0", "0");
            MyCookie += HttpCookieHelper.CookieFormat("randomSeed", "795140");
            MyCookie += HttpCookieHelper.CookieFormat("rankv", "2017082215");
            MyCookie += HttpCookieHelper.CookieFormat("tvfe_boss_uuid", "0d52aadbb97e9dd5");
            MyCookie += HttpCookieHelper.CookieFormat("ue_skey", "012d2021e58c97ab54f02c6764d1f14a");
            MyCookie += HttpCookieHelper.CookieFormat("ue_ts", "1508678554");
            MyCookie += HttpCookieHelper.CookieFormat("ue_uid", "33cb1ba9ccaebf617da99cec0ca8d569");
            MyCookie += HttpCookieHelper.CookieFormat("ue_uk", "68f76c6fcccdbf3bfc6903bb54d66919");
            MyCookie += HttpCookieHelper.CookieFormat("zzpaneluin", "");
            MyCookie += HttpCookieHelper.CookieFormat("zzpanelkey", "");


            //MessageBox.Show(HR.Cookie);

            string AllCookie = outcomeFromLogin.Cookie + HR.Cookie;//outcomeFromLogin.Cookie + HR.Cookie;

            //MessageBox.Show(MyCookie);
            //Return_box.Text = AllCookie;

            HttpItem m = new HttpItem
            {
                URL = "https://user.qzone.qq.com/66456804",
                //CookieCollection = outcomeFromLogin.CookieCollection,
                Cookie = MyCookie,
                Host = "user.qzone.qq.com",
                Referer = "https://qzone.qq.com/",
                //UserAgent = "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)",
                //Accept = "text/html, application/xhtml+xml, image/jxr, */*"

            };

            outcomeFromLogin = helper1.GetHtml(m);
            revFromLogin = outcomeFromLogin.Html;
            //Return_box.Text = revFromLogin; //打印登录后返回信息
            //MessageBox.Show(outcomeFromLogin.Html);
            //MessageBox.Show(outcomeFromLogin.Cookie);


        }

        private void QQ_acount_box_TextChanged(object sender, EventArgs e)
        {
            this.QQ = QQ_acount_box.Text;
        }
        
        private void QQ_pass_box_TextChanged(object sender, EventArgs e)
        {
            this.password = QQ_pass_box.Text;
        }

        private void Return_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void Vericode_box_TextChanged(object sender, EventArgs e)
        {
            this.verifycode = Vericode_box.Text;
        }

        private void QQ_acount_box_Leave_1(object sender, EventArgs e) //当焦点(光标)离开QQ账号输入框是触发此函数，获取验证码
        {
            GetCheck();
        }

        private void LoginForm_Activated(object sender, EventArgs e)
        {
            QQ_acount_box.Focus();
        }

        private void pictureBox1_DoubleClick(object sender, EventArgs e) //双击时刷新验证码
        {
            GetCheck();
        }

        private string GetLoginSig()
        {
            String forCheckUrl = "https://xui.ptlogin2.qq.com/cgi-bin/xlogin?proxy_url=https%3A//qzs.qq.com/qzone/v6/portal/proxy.html&daid=5&&hide_title_bar=1&low_login=0&qlogin_auto_login=1&no_verifyimg=1&link_target=blank&appid=549000912&style=22&target=self&s_url=https%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&pt_qr_app=%E6%89%8B%E6%9C%BAQQ%E7%A9%BA%E9%97%B4&pt_qr_link=https%3A//z.qzone.com/download.html&self_regurl=https%3A//qzs.qq.com/qzone/v6/reg/index.html&pt_qr_help_link=https%3A//z.qzone.com/download.html&pt_no_auth=0";
            HttpHelper helper = new HttpHelper();
            outcomeFromCheck = helper.GetHtml(new HttpItem { URL = forCheckUrl});
            return HttpCookieHelper.GetCookieValue("pt_login_sig", outcomeFromCheck.Cookie);
        }

        private void GetCheck()
        {
            //获取验证信息
            //验证信息格式为：ptui_checkVC('0','!MIW','\x00\x00\x00\x00\x9a\x65\x0f\xd7') 
            //其中分为三部分，第一个值0或1判断是否需要图片验证码
            //                          第二个值是默认验证码，若不需要图片验证码，就用此验证码来提交
            //                          第三部分是所使用的QQ号码的16进制形式
            pt_login_sig = GetLoginSig();
            String forCheckUrl = "https://ssl.ptlogin2.qq.com/check?regmaster=&pt_tea=2&pt_vcode=1&uin=" + QQ + "&appid=549000912&js_ver=10231&js_type=1&login_sig="+ pt_login_sig +"&u1=https%3A%2F%2Fqzs.qq.com%2Fqzone%2Fv5%2Floginsucc.html%3Fpara%3Dizone&r=0.6734757612847391&pt_uistyle=40&pt_jstoken=3611214356";
            CookieContainer cookieNull = new CookieContainer();
            HttpHelper helper = new HttpHelper()
            {
                
            };


            HttpItem h = new HttpItem() { URL = forCheckUrl,ResultType = ResultType.String };
            String receiveFromCheck = "";

            HttpResult result = helper.GetHtml(h);
            receiveFromCheck = result.Html;

            ptv = HttpCookieHelper.GetCookieValue("ptvfsession", result.Cookie);

            //将验证码信息的三部分存入数组
            int checkCodePosition = receiveFromCheck.IndexOf("(") + 1;
            String checkCode = receiveFromCheck.Substring(checkCodePosition, receiveFromCheck.LastIndexOf(")") - checkCodePosition);
            String[] checkNum = checkCode.Replace("'", "").Split(',');  //验证码数组


            if ("1".Equals(checkNum[0])) //判断是否需要图片验证码
            {
                hasimage = 1;
                String forImageUrl = "http://captcha.qq.com/getimage?aid=549000912&uin=" + QQ + "&cap_cd=" + checkNum[1];
                Stream receiveStream = new MemoryStream(helper.GetHtml(new HttpItem { URL = forImageUrl, ResultType = ResultType.Byte }).ResultByte);
                //将获取的图片验证码存入电脑
                //System.Drawing.Image.FromStream(receiveStream).Save(@"d:/code.jpg");
                Image img = Image.FromStream(receiveStream);
                pictureBox1.Image = img; //将读取到的图片验证码输出到picture_box面板上
            }
            else //若不需图片验证码，验证码就等于checkNum[1]
            {
                hasimage = 0;
                Vericode_box.Text = checkNum[1];
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e) //当鼠标在有图片显示的picturebox上移动时提醒可刷新验证码
        {
            if (hasimage==1)
            {
                toolTip1.SetToolTip(pictureBox1, "双击可以刷新验证码");
            }
        }
        private string ExecuteScript(string sExpression, string sCode)
         {
             MSScriptControl.ScriptControl scriptControl = new MSScriptControl.ScriptControl();
             scriptControl.UseSafeSubset = true;
             scriptControl.Language = "JScript";
             scriptControl.AddCode(sCode);
             try
             {
                 string str = scriptControl.Eval(sExpression).ToString();
                 return str;
             }
             catch (Exception ex)
             {
                 string str = ex.Message;
             }
             return null;
        }

        string GetEncryption()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "test.js";
            string str2 = File.ReadAllText(path);

            string fun = "getmd5(\"" + QQ + "\",\"" + password + "\",\"" + Vericode_box.Text + "\")";
            string result = ExecuteScript(fun, str2);
            //result = result.Replace('/', '-');
            //result = result.Replace('+', '*');
            //result = result.Replace('=', '_');
            return result;
        }

        private void button2_Click(object sender, EventArgs e)
        {



        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }
    public struct RetData //网页请求返回对象
    {
        public string str;
        public CookieContainer cookie;
    }
}
